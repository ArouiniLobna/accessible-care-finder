import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@acf/ui/styles.css';
import { App } from './app/App';

const root = document.getElementById('root');
if (!root) throw new Error('Missing #root element');

createRoot(root).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
